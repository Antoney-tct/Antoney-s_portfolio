"use client"

import { useEffect, useRef, useState } from "react"
import Image from "next/image"
import { Star, Quote } from "lucide-react"
import { testimonials } from "@/lib/data"
import { cn } from "@/lib/utils"

export function TestimonialsSection() {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute("data-index"))
            setVisibleCards((prev) => new Set([...prev, index]))
          }
        })
      },
      { threshold: 0.15 }
    )

    const cards = sectionRef.current?.querySelectorAll("[data-test]")
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [])

  return (
    <section ref={sectionRef} className="py-20">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-12">
          <h2 className="inline-block text-3xl sm:text-4xl font-bold text-primary relative pb-3">
            Client Testimonials
            <span className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-red-400 rounded-sm" />
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {testimonials.map((t, index) => (
            <div
              key={t.name}
              data-test
              data-index={index}
              className={cn(
                "bg-card rounded-xl p-7 shadow-[0_10px_25px_-5px_rgba(30,58,138,0.08)] relative transition-all duration-500 hover:-translate-y-3 hover:shadow-[0_20px_40px_-10px_rgba(30,58,138,0.15)]",
                visibleCards.has(index)
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              )}
              style={{ transitionDelay: `${index * 120}ms` }}
            >
              <Quote className="absolute top-5 right-5 w-10 h-10 text-primary/10" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                ))}
              </div>
              <p className="text-muted-foreground leading-relaxed text-[0.95rem] mb-5 italic">
                {'"'}{t.text}{'"'}
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <Image
                  src={t.avatar}
                  alt={t.name}
                  width={48}
                  height={48}
                  className="rounded-full object-cover"
                />
                <div>
                  <h4 className="font-bold text-primary text-sm">{t.name}</h4>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
