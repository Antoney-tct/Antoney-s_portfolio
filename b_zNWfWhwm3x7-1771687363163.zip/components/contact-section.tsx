"use client"

import { useState } from "react"
import { Mail, Phone, MapPin, Send, Linkedin, Github, Facebook, Instagram, ExternalLink } from "lucide-react"
import { siteConfig } from "@/lib/data"

export function ContactSection() {
  const [form, setForm] = useState({ name: "", email: "", subject: "", message: "" })
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
    setForm({ name: "", email: "", subject: "", message: "" })
    setTimeout(() => setSubmitted(false), 4000)
  }

  return (
    <section id="contact" className="py-20 bg-card">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-12">
          <h2 className="inline-block text-3xl sm:text-4xl font-bold text-primary relative pb-3">
            Get In Touch
            <span className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-red-400 rounded-sm" />
          </h2>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mt-8">
          {/* Contact Info */}
          <div>
            <h3 className="text-2xl font-bold text-primary mb-4">{"Let's Work Together"}</h3>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Have a project in mind or want to discuss a potential collaboration? Feel free to reach out using the form or any of the contact methods below.
            </p>
            <div className="space-y-5 mb-8">
              <a
                href={`mailto:${siteConfig.email}`}
                className="flex items-center gap-4 group no-underline"
              >
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-300">
                  <Mail className="w-5 h-5 text-accent group-hover:text-accent-foreground" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground text-sm">Email</h4>
                  <p className="text-muted-foreground text-sm">{siteConfig.email}</p>
                </div>
              </a>
              <a
                href={`tel:${siteConfig.phone.replace(/\s/g, "")}`}
                className="flex items-center gap-4 group no-underline"
              >
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary group-hover:text-primary-foreground transition-all duration-300">
                  <Phone className="w-5 h-5 text-primary group-hover:text-primary-foreground" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground text-sm">Phone</h4>
                  <p className="text-muted-foreground text-sm">{siteConfig.phone}</p>
                </div>
              </a>
              <div className="flex items-center gap-4 group">
                <div className="w-12 h-12 rounded-full bg-accent/10 flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <h4 className="font-bold text-foreground text-sm">Location</h4>
                  <p className="text-muted-foreground text-sm">{siteConfig.location}</p>
                </div>
              </div>
            </div>
            <h4 className="font-bold text-primary text-sm mb-3">Follow Me</h4>
            <div className="flex gap-3">
              {[
                { Icon: Linkedin, href: siteConfig.social.linkedin, label: "LinkedIn" },
                { Icon: Github, href: siteConfig.social.github, label: "GitHub" },
                { Icon: Facebook, href: siteConfig.social.facebook, label: "Facebook" },
                { Icon: Instagram, href: siteConfig.social.instagram, label: "Instagram" },
                { Icon: ExternalLink, href: siteConfig.social.tiktok, label: "TikTok" },
              ].map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-secondary flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-300"
                  aria-label={label}
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <form
            onSubmit={handleSubmit}
            className="bg-background rounded-xl p-7 shadow-[0_10px_25px_-5px_rgba(30,58,138,0.08)]"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label htmlFor="name" className="block font-bold text-foreground text-sm mb-2">
                  Your Name
                </label>
                <input
                  id="name"
                  type="text"
                  required
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-card border-2 border-border text-foreground text-sm outline-none focus:border-accent transition-colors"
                  placeholder="Antoney Ouko"
                />
              </div>
              <div>
                <label htmlFor="email" className="block font-bold text-foreground text-sm mb-2">
                  Your Email
                </label>
                <input
                  id="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full px-4 py-3 rounded-lg bg-card border-2 border-border text-foreground text-sm outline-none focus:border-accent transition-colors"
                  placeholder="antoney@example.com"
                />
              </div>
            </div>
            <div className="mt-5">
              <label htmlFor="subject" className="block font-bold text-foreground text-sm mb-2">
                Subject
              </label>
              <input
                id="subject"
                type="text"
                required
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-card border-2 border-border text-foreground text-sm outline-none focus:border-accent transition-colors"
                placeholder="Project Inquiry"
              />
            </div>
            <div className="mt-5">
              <label htmlFor="message" className="block font-bold text-foreground text-sm mb-2">
                Message
              </label>
              <textarea
                id="message"
                rows={5}
                required
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                className="w-full px-4 py-3 rounded-lg bg-card border-2 border-border text-foreground text-sm outline-none focus:border-accent transition-colors resize-y"
                placeholder="Tell me about your project..."
              />
            </div>
            <button
              type="submit"
              className="mt-5 w-full inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-full bg-gradient-to-r from-accent to-red-400 text-accent-foreground font-semibold text-sm cursor-pointer hover:-translate-y-0.5 hover:shadow-[0_10px_25px_rgba(220,38,38,0.3)] transition-all duration-300"
            >
              <Send className="w-4 h-4" />
              Send Message
            </button>
            {submitted && (
              <p className="mt-4 text-center text-sm font-semibold text-green-600">
                Thank you! Your message has been sent successfully.
              </p>
            )}
          </form>
        </div>
      </div>
    </section>
  )
}
