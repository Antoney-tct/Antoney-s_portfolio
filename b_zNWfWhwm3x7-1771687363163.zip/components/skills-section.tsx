"use client"

import { useEffect, useRef, useState } from "react"
import {
  Code,
  Paintbrush,
  TrendingUp,
  PieChart,
  Shield,
  Megaphone,
  ListTodo,
} from "lucide-react"
import { skills } from "@/lib/data"
import { cn } from "@/lib/utils"

const iconMap: Record<string, React.ElementType> = {
  Code,
  Paintbrush,
  TrendingUp,
  PieChart,
  Shield,
  Megaphone,
  ListTodo,
}

export function SkillsSection() {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const sectionRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute("data-index"))
            setVisibleCards((prev) => new Set([...prev, index]))
          }
        })
      },
      { threshold: 0.15 }
    )

    const cards = sectionRef.current?.querySelectorAll("[data-index]")
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [])

  return (
    <section id="skills" ref={sectionRef} className="py-20 bg-card">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-12">
          <h2 className="inline-block text-3xl sm:text-4xl font-bold text-primary relative pb-3">
            My Skills
            <span className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-red-400 rounded-sm" />
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mt-8">
          {skills.map((skill, index) => {
            const Icon = iconMap[skill.icon]
            const isRed = skill.color === "red"
            return (
              <div
                key={skill.title}
                data-index={index}
                className={cn(
                  "bg-card rounded-xl shadow-[0_10px_25px_-5px_rgba(30,58,138,0.08)] p-7 transition-all duration-500 border-t-4 hover:-translate-y-3 hover:shadow-[0_20px_40px_-10px_rgba(30,58,138,0.15)]",
                  isRed ? "border-t-accent" : "border-t-primary",
                  visibleCards.has(index)
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                )}
                style={{ transitionDelay: `${index * 80}ms` }}
              >
                <Icon
                  className={cn(
                    "w-10 h-10 mb-5",
                    isRed ? "text-accent" : "text-primary"
                  )}
                />
                <h3 className="text-xl font-bold text-primary mb-4">{skill.title}</h3>
                <ul className="space-y-0">
                  {skill.items.map((item, i) => (
                    <li
                      key={i}
                      className={cn(
                        "flex items-center justify-between py-2.5 px-2.5 rounded-md transition-all duration-300 hover:bg-background hover:translate-x-1",
                        i < skill.items.length - 1 && "border-b border-dashed border-border"
                      )}
                    >
                      <span className="text-sm font-medium text-foreground">
                        {item.name}
                      </span>
                      <span
                        className={cn(
                          "text-xs font-semibold px-3 py-1 rounded-full",
                          isRed
                            ? "bg-accent/10 text-accent"
                            : "bg-primary/10 text-primary"
                        )}
                      >
                        {item.level}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
