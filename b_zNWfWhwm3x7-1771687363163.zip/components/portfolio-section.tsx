"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import { ExternalLink, X, Calendar, User, Tag } from "lucide-react"
import { portfolioItems, filterCategories } from "@/lib/data"
import { cn } from "@/lib/utils"

export function PortfolioSection() {
  const [activeFilter, setActiveFilter] = useState("all")
  const [selectedProject, setSelectedProject] = useState<typeof portfolioItems[0] | null>(null)
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set())
  const sectionRef = useRef<HTMLElement>(null)

  const filteredItems =
    activeFilter === "all"
      ? portfolioItems
      : portfolioItems.filter((item) => item.category === activeFilter)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = Number(entry.target.getAttribute("data-index"))
            setVisibleCards((prev) => new Set([...prev, index]))
          }
        })
      },
      { threshold: 0.1 }
    )

    const cards = sectionRef.current?.querySelectorAll("[data-portfolio]")
    cards?.forEach((card) => observer.observe(card))

    return () => observer.disconnect()
  }, [filteredItems])

  useEffect(() => {
    document.body.style.overflow = selectedProject ? "hidden" : ""
    return () => { document.body.style.overflow = "" }
  }, [selectedProject])

  return (
    <section id="portfolio" ref={sectionRef} className="py-20">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-12">
          <h2 className="inline-block text-3xl sm:text-4xl font-bold text-primary relative pb-3">
            My Portfolio
            <span className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-accent to-red-400 rounded-sm" />
          </h2>
        </div>

        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {filterCategories.map((cat, i) => (
            <button
              key={cat.value}
              onClick={() => {
                setActiveFilter(cat.value)
                setVisibleCards(new Set())
              }}
              className={cn(
                "px-5 py-2.5 rounded-full font-semibold text-sm border-2 border-transparent transition-all duration-300 cursor-pointer",
                activeFilter === cat.value
                  ? i === 1
                    ? "bg-gradient-to-r from-accent to-red-400 text-accent-foreground shadow-[0_5px_15px_rgba(220,38,38,0.2)]"
                    : "bg-gradient-to-r from-primary to-ring text-primary-foreground shadow-[0_5px_15px_rgba(30,58,138,0.2)]"
                  : "bg-secondary text-muted-foreground hover:bg-gradient-to-r hover:from-primary hover:to-ring hover:text-primary-foreground"
              )}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Portfolio Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {filteredItems.map((item, index) => (
            <div
              key={item.id}
              data-portfolio
              data-index={index}
              className={cn(
                "bg-card rounded-xl overflow-hidden shadow-[0_10px_25px_-5px_rgba(30,58,138,0.08)] transition-all duration-500 group cursor-pointer hover:-translate-y-3 hover:shadow-[0_20px_40px_-10px_rgba(30,58,138,0.15)]",
                visibleCards.has(index)
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              )}
              style={{ transitionDelay: `${index * 100}ms` }}
              onClick={() => setSelectedProject(item)}
            >
              <div className="relative h-56 overflow-hidden">
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-primary/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <span className="px-6 py-3 bg-card text-primary rounded-full font-semibold text-sm shadow-lg flex items-center gap-2 translate-y-5 group-hover:translate-y-0 transition-transform duration-300">
                    <ExternalLink className="w-4 h-4" />
                    View Project
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-bold text-primary mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {item.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {item.tags.map((tag) => (
                    <span
                      key={tag}
                      className="bg-primary/10 text-primary text-xs font-semibold px-3 py-1 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Project Modal */}
      {selectedProject && (
        <div
          className="fixed inset-0 z-[2000] bg-foreground/60 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setSelectedProject(null)}
        >
          <div
            className="bg-card rounded-xl w-full max-w-[900px] max-h-[90vh] overflow-y-auto relative animate-fade-in-up"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-4 right-4 w-10 h-10 rounded-full bg-secondary text-foreground flex items-center justify-center hover:bg-accent hover:text-accent-foreground transition-all duration-300 z-10"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
              <div className="relative h-64 md:h-auto min-h-[280px]">
                <Image
                  src={selectedProject.image}
                  alt={selectedProject.title}
                  fill
                  className="object-cover rounded-t-xl md:rounded-l-xl md:rounded-tr-none"
                />
              </div>
              <div className="p-7">
                <h3 className="text-2xl font-bold text-primary mb-3">
                  {selectedProject.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-5 text-[0.95rem]">
                  {selectedProject.fullDescription}
                </p>
                <ul className="space-y-2.5 py-4 border-y border-border mb-5">
                  <li className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Tag className="w-4 h-4 text-accent" />
                    <strong className="text-foreground min-w-[70px]">Category:</strong>
                    {filterCategories.find((c) => c.value === selectedProject.category)?.label || selectedProject.category}
                  </li>
                  <li className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="w-4 h-4 text-accent" />
                    <strong className="text-foreground min-w-[70px]">Client:</strong>
                    {selectedProject.client}
                  </li>
                  <li className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4 text-accent" />
                    <strong className="text-foreground min-w-[70px]">Date:</strong>
                    {selectedProject.date}
                  </li>
                </ul>
                <div className="flex flex-wrap gap-2 mb-5">
                  {selectedProject.tags.map((tag) => (
                    <span
                      key={tag}
                      className="bg-primary/10 text-primary text-xs font-semibold px-3 py-1 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
                {selectedProject.link && (
                  <a
                    href={selectedProject.link}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-primary to-ring text-primary-foreground font-semibold text-sm no-underline hover:-translate-y-0.5 transition-all duration-300 shadow-md"
                  >
                    <ExternalLink className="w-4 h-4" />
                    View Project
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  )
}
