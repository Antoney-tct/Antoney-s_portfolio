"use client"

import Link from "next/link"
import { Code, Linkedin, Github, Facebook, Instagram, ExternalLink, ArrowUp } from "lucide-react"
import { siteConfig } from "@/lib/data"

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground pt-16 pb-8">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Brand */}
          <div>
            <div className="flex items-center font-extrabold text-xl mb-4">
              <Code className="mr-2 w-6 h-6" />
              <span>Antoney</span>
              <span className="text-accent ml-1">Ouko</span>
            </div>
            <p className="text-primary-foreground/70 text-sm leading-relaxed">
              Business IT Specialist, Designer, Analyst & Creative Developer based in Nairobi, Kenya. Creating digital solutions that blend technology with creativity.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2.5">
              {["Home", "Skills", "Portfolio", "Blog", "Contact"].map((item) => (
                <li key={item}>
                  <Link
                    href={`#${item.toLowerCase()}`}
                    className="text-primary-foreground/70 text-sm no-underline hover:text-accent transition-colors"
                  >
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Socials */}
          <div>
            <h3 className="text-lg font-bold mb-4">Connect With Me</h3>
            <div className="flex gap-3">
              {[
                { Icon: Linkedin, href: siteConfig.social.linkedin, label: "LinkedIn" },
                { Icon: Github, href: siteConfig.social.github, label: "GitHub" },
                { Icon: Facebook, href: siteConfig.social.facebook, label: "Facebook" },
                { Icon: Instagram, href: siteConfig.social.instagram, label: "Instagram" },
                { Icon: ExternalLink, href: siteConfig.social.tiktok, label: "TikTok" },
              ].map(({ Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full bg-primary-foreground/10 flex items-center justify-center text-primary-foreground/70 hover:bg-accent hover:text-accent-foreground transition-all duration-300"
                  aria-label={label}
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="border-t border-primary-foreground/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-primary-foreground/60 text-sm">
            {new Date().getFullYear()} Antoney Ouko. All rights reserved.
          </p>
          <Link
            href="#home"
            className="w-10 h-10 rounded-full bg-accent text-accent-foreground flex items-center justify-center hover:-translate-y-1 transition-all duration-300"
            aria-label="Back to top"
          >
            <ArrowUp className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </footer>
  )
}
