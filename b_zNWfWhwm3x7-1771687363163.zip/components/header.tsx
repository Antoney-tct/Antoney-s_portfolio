"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useTheme } from "next-themes"
import { Code, Moon, Sun, Menu, X } from "lucide-react"
import { cn } from "@/lib/utils"

const navItems = [
  { label: "Home", href: "#home" },
  { label: "Skills", href: "#skills" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Blog", href: "#blog" },
  { label: "Contact", href: "#contact" },
]

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : ""
    return () => {
      document.body.style.overflow = ""
    }
  }, [mobileOpen])

  const handleNavClick = () => {
    setMobileOpen(false)
  }

  return (
    <header
      className={cn(
        "fixed top-0 left-0 w-full z-50 transition-all duration-300",
        "bg-card/95 backdrop-blur-md",
        isScrolled ? "py-3 shadow-lg" : "py-4 shadow-md"
      )}
    >
      <div className="max-w-[1200px] mx-auto px-5 flex items-center justify-between">
        <Link href="#home" className="flex items-center text-primary font-extrabold text-2xl no-underline">
          <Code className="mr-2 w-7 h-7" />
          <span>Antoney</span>
          <span className="text-accent ml-1">Ouko</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center">
          <ul className="flex items-center list-none">
            {navItems.map((item) => (
              <li key={item.label} className="ml-8">
                <Link
                  href={item.href}
                  className="text-foreground font-semibold text-[1.05rem] no-underline hover:text-accent transition-colors duration-300 relative after:content-[''] after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-[3px] after:bg-accent after:rounded-sm after:transition-all after:duration-300 hover:after:w-full"
                >
                  {item.label}
                </Link>
              </li>
            ))}
            <li className="ml-8">
              <Link
                href="#contact"
                className="inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-gradient-to-r from-accent to-red-400 text-accent-foreground font-semibold text-sm no-underline hover:-translate-y-0.5 transition-all duration-300 shadow-md hover:shadow-lg"
              >
                Hire Me
              </Link>
            </li>
            <li className="ml-5">
              <button
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="w-10 h-10 rounded-full border-2 border-border bg-transparent text-foreground flex items-center justify-center cursor-pointer hover:bg-secondary hover:text-primary transition-all duration-300"
                aria-label="Toggle theme"
              >
                {mounted && (theme === "dark" ? <Sun className="w-[1.15rem] h-[1.15rem]" /> : <Moon className="w-[1.15rem] h-[1.15rem]" />)}
              </button>
            </li>
          </ul>
        </nav>

        {/* Mobile Buttons */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            className="w-10 h-10 rounded-full border-2 border-border bg-transparent text-foreground flex items-center justify-center"
            aria-label="Toggle theme"
          >
            {mounted && (theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />)}
          </button>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-ring text-primary-foreground flex items-center justify-center shadow-md z-[1001]"
            aria-label="Toggle navigation menu"
          >
            {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Nav Overlay */}
        {mobileOpen && (
          <div
            className="fixed inset-0 bg-foreground/20 z-[999] md:hidden"
            onClick={() => setMobileOpen(false)}
          />
        )}

        {/* Mobile Nav Panel */}
        <nav
          className={cn(
            "fixed top-0 right-0 w-72 h-screen bg-card flex flex-col pt-24 px-7 pb-7 shadow-[-10px_0_30px_rgba(0,0,0,0.1)] transition-transform duration-300 z-[1000] md:hidden",
            mobileOpen ? "translate-x-0" : "translate-x-full"
          )}
        >
          {navItems.map((item) => (
            <Link
              key={item.label}
              href={item.href}
              onClick={handleNavClick}
              className="text-foreground font-semibold text-lg no-underline py-3 border-b border-border hover:text-accent transition-colors"
            >
              {item.label}
            </Link>
          ))}
          <Link
            href="#contact"
            onClick={handleNavClick}
            className="mt-6 inline-flex items-center justify-center px-6 py-3 rounded-full bg-gradient-to-r from-accent to-red-400 text-accent-foreground font-semibold text-sm no-underline"
          >
            Hire Me
          </Link>
        </nav>
      </div>
    </header>
  )
}
