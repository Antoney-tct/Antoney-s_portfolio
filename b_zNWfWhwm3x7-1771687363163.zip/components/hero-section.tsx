"use client"

import { useEffect, useState } from "react"
import { Eye, Send, Download, ChevronDown } from "lucide-react"
import Link from "next/link"

export function HeroSection() {
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    setVisible(true)
  }, [])

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-32 pb-20 overflow-hidden">
      {/* Background shapes */}
      <div className="absolute -top-24 -right-24 w-[500px] h-[500px] bg-gradient-to-br from-primary to-ring rounded-full opacity-[0.04] pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-[350px] h-[350px] bg-gradient-to-br from-accent to-red-400 rounded-full opacity-[0.04] pointer-events-none" />

      <div className="max-w-[1200px] mx-auto px-5 flex flex-col lg:flex-row items-center w-full">
        {/* Content */}
        <div
          className={`flex-1 lg:pr-12 text-center lg:text-left transition-all duration-700 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <h1 className="text-4xl sm:text-5xl lg:text-[4rem] font-extrabold leading-tight mb-4 text-balance bg-gradient-to-r from-primary to-ring bg-clip-text text-transparent">
            Antoney Ouko
          </h1>
          <h2 className="text-lg sm:text-xl lg:text-2xl text-muted-foreground font-medium mb-6 text-pretty">
            Business IT Specialist, Designer, Analyst & Creative Developer
          </h2>
          <p className="text-base lg:text-lg text-muted-foreground leading-relaxed mb-8 max-w-[600px] mx-auto lg:mx-0">
            I build <span className="text-accent font-bold">digital experiences</span> that combine technical precision with visual excellence. With expertise in{" "}
            <span className="text-accent font-bold">QA testing</span>,{" "}
            <span className="text-accent font-bold">web development</span>,{" "}
            <span className="text-accent font-bold">graphic design</span>, and{" "}
            <span className="text-accent font-bold">IT support</span>, I create solutions that are both functional and beautiful.
          </p>
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4">
            <Link
              href="#portfolio"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full bg-gradient-to-r from-primary to-ring text-primary-foreground font-semibold text-sm no-underline shadow-[0_4px_15px_rgba(30,58,138,0.3)] hover:-translate-y-1 hover:shadow-[0_10px_25px_rgba(30,58,138,0.4)] transition-all duration-300"
            >
              <Eye className="w-4 h-4" />
              View My Work
            </Link>
            <Link
              href="#contact"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border-2 border-primary text-primary font-semibold text-sm no-underline hover:bg-primary hover:text-primary-foreground hover:-translate-y-1 transition-all duration-300"
            >
              <Send className="w-4 h-4" />
              Get In Touch
            </Link>
            <a
              href="#"
              className="inline-flex items-center gap-2 px-7 py-3.5 rounded-full border-2 border-primary text-primary font-semibold text-sm no-underline hover:bg-primary hover:text-primary-foreground hover:-translate-y-1 transition-all duration-300"
            >
              <Download className="w-4 h-4" />
              Download Resume
            </a>
          </div>
        </div>

        {/* Profile Image */}
        <div
          className={`flex-1 flex justify-center mt-12 lg:mt-0 transition-all duration-700 delay-200 ${
            visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="animate-float">
            <div className="w-72 h-72 sm:w-80 sm:h-80 lg:w-[360px] lg:h-[360px] rounded-[30%_70%_70%_30%/30%_30%_70%_70%] bg-gradient-to-br from-primary to-ring flex items-center justify-center shadow-[0_20px_40px_-10px_rgba(30,58,138,0.25)] relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-accent to-red-400 opacity-20 rounded-[inherit]" />
              <div className="w-full h-full flex items-center justify-center text-primary-foreground text-7xl font-extrabold">
                AO
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <Link
        href="#skills"
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-primary opacity-60 hover:opacity-100 hover:text-accent transition-all duration-300 animate-bounce"
        aria-label="Scroll down"
      >
        <ChevronDown className="w-7 h-7" />
      </Link>
    </section>
  )
}
